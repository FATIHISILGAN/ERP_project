﻿namespace exERP_Full
{
    partial class stok_düzenle
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.çıkış = new System.Windows.Forms.Label();
            this.ürün_id = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.ürün_ad = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.ürün_adet = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.üts_text = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.Güncelle_btn = new System.Windows.Forms.Button();
            this.kaydet_btn = new System.Windows.Forms.Button();
            this.Sil = new System.Windows.Forms.Button();
            this.silincek_text = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // çıkış
            // 
            this.çıkış.AutoSize = true;
            this.çıkış.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.çıkış.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.çıkış.Location = new System.Drawing.Point(0, 0);
            this.çıkış.Name = "çıkış";
            this.çıkış.Size = new System.Drawing.Size(18, 18);
            this.çıkış.TabIndex = 18;
            this.çıkış.Text = "X";
            this.çıkış.Click += new System.EventHandler(this.çıkış_Click);
            this.çıkış.MouseLeave += new System.EventHandler(this.çıkış_MouseLeave);
            this.çıkış.MouseMove += new System.Windows.Forms.MouseEventHandler(this.çıkış_MouseMove);
            // 
            // ürün_id
            // 
            this.ürün_id.Location = new System.Drawing.Point(163, 106);
            this.ürün_id.Name = "ürün_id";
            this.ürün_id.Size = new System.Drawing.Size(100, 20);
            this.ürün_id.TabIndex = 20;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.label1.Location = new System.Drawing.Point(105, 106);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(52, 18);
            this.label1.TabIndex = 19;
            this.label1.Text = "ürün id";
            // 
            // ürün_ad
            // 
            this.ürün_ad.Location = new System.Drawing.Point(163, 163);
            this.ürün_ad.Name = "ürün_ad";
            this.ürün_ad.Size = new System.Drawing.Size(100, 20);
            this.ürün_ad.TabIndex = 22;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.label2.Location = new System.Drawing.Point(104, 163);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(57, 18);
            this.label2.TabIndex = 21;
            this.label2.Text = "ürün ad";
            // 
            // ürün_adet
            // 
            this.ürün_adet.Location = new System.Drawing.Point(163, 212);
            this.ürün_adet.Name = "ürün_adet";
            this.ürün_adet.Size = new System.Drawing.Size(100, 20);
            this.ürün_adet.TabIndex = 24;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.label3.Location = new System.Drawing.Point(83, 212);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(69, 18);
            this.label3.TabIndex = 23;
            this.label3.Text = "ürün adet";
            // 
            // üts_text
            // 
            this.üts_text.Location = new System.Drawing.Point(163, 262);
            this.üts_text.Name = "üts_text";
            this.üts_text.Size = new System.Drawing.Size(100, 20);
            this.üts_text.TabIndex = 26;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label4.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.label4.Location = new System.Drawing.Point(20, 261);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(137, 18);
            this.label4.TabIndex = 25;
            this.label4.Text = "ürün toplam satılma";
            // 
            // Güncelle_btn
            // 
            this.Güncelle_btn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(43)))), ((int)(((byte)(46)))));
            this.Güncelle_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.Güncelle_btn.ForeColor = System.Drawing.Color.SlateGray;
            this.Güncelle_btn.Location = new System.Drawing.Point(163, 354);
            this.Güncelle_btn.Name = "Güncelle_btn";
            this.Güncelle_btn.Size = new System.Drawing.Size(93, 27);
            this.Güncelle_btn.TabIndex = 28;
            this.Güncelle_btn.Text = "Güncelle";
            this.Güncelle_btn.UseVisualStyleBackColor = false;
            this.Güncelle_btn.Click += new System.EventHandler(this.Güncelle_btn_Click);
            // 
            // kaydet_btn
            // 
            this.kaydet_btn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(43)))), ((int)(((byte)(46)))));
            this.kaydet_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.kaydet_btn.ForeColor = System.Drawing.Color.SlateGray;
            this.kaydet_btn.Location = new System.Drawing.Point(163, 311);
            this.kaydet_btn.Name = "kaydet_btn";
            this.kaydet_btn.Size = new System.Drawing.Size(93, 27);
            this.kaydet_btn.TabIndex = 27;
            this.kaydet_btn.Text = "Kaydet";
            this.kaydet_btn.UseVisualStyleBackColor = false;
            this.kaydet_btn.Click += new System.EventHandler(this.kaydet_btn_Click);
            // 
            // Sil
            // 
            this.Sil.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(43)))), ((int)(((byte)(46)))));
            this.Sil.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.Sil.ForeColor = System.Drawing.Color.SlateGray;
            this.Sil.Location = new System.Drawing.Point(421, 210);
            this.Sil.Name = "Sil";
            this.Sil.Size = new System.Drawing.Size(93, 27);
            this.Sil.TabIndex = 31;
            this.Sil.Text = "Sil";
            this.Sil.UseVisualStyleBackColor = false;
            this.Sil.Click += new System.EventHandler(this.Sil_Click);
            // 
            // silincek_text
            // 
            this.silincek_text.Location = new System.Drawing.Point(415, 161);
            this.silincek_text.Name = "silincek_text";
            this.silincek_text.Size = new System.Drawing.Size(100, 20);
            this.silincek_text.TabIndex = 30;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label7.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.label7.Location = new System.Drawing.Point(375, 161);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(22, 18);
            this.label7.TabIndex = 29;
            this.label7.Text = "ID";
            // 
            // stok_düzenle
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(45)))), ((int)(((byte)(48)))));
            this.ClientSize = new System.Drawing.Size(604, 407);
            this.Controls.Add(this.Sil);
            this.Controls.Add(this.silincek_text);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.Güncelle_btn);
            this.Controls.Add(this.kaydet_btn);
            this.Controls.Add(this.üts_text);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.ürün_adet);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.ürün_ad);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.ürün_id);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.çıkış);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "stok_düzenle";
            this.Text = "stok_düzenle";
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.stok_düzenle_MouseDown);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.stok_düzenle_MouseMove);
            this.MouseUp += new System.Windows.Forms.MouseEventHandler(this.stok_düzenle_MouseUp);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label çıkış;
        private System.Windows.Forms.TextBox ürün_id;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox ürün_ad;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox ürün_adet;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox üts_text;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button Güncelle_btn;
        private System.Windows.Forms.Button kaydet_btn;
        private System.Windows.Forms.Button Sil;
        private System.Windows.Forms.TextBox silincek_text;
        private System.Windows.Forms.Label label7;
    }
}