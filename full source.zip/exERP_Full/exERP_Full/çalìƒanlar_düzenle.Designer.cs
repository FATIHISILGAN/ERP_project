﻿namespace exERP_Full
{
    partial class çalışanlar_düzenle
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.Id_text = new System.Windows.Forms.TextBox();
            this.şifre_text = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.maaş_text = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.adsoyad_text = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.meslek_text = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.svg_text = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.kaydet_btn = new System.Windows.Forms.Button();
            this.Güncelle_btn = new System.Windows.Forms.Button();
            this.silincek_text = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.Sil = new System.Windows.Forms.Button();
            this.çıkış = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.label1.Location = new System.Drawing.Point(103, 35);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(22, 18);
            this.label1.TabIndex = 0;
            this.label1.Text = "ID";
            // 
            // Id_text
            // 
            this.Id_text.Location = new System.Drawing.Point(143, 35);
            this.Id_text.Name = "Id_text";
            this.Id_text.Size = new System.Drawing.Size(100, 20);
            this.Id_text.TabIndex = 1;
            // 
            // şifre_text
            // 
            this.şifre_text.Location = new System.Drawing.Point(143, 88);
            this.şifre_text.Name = "şifre_text";
            this.şifre_text.Size = new System.Drawing.Size(100, 20);
            this.şifre_text.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.label2.Location = new System.Drawing.Point(99, 90);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(38, 18);
            this.label2.TabIndex = 2;
            this.label2.Text = "Şifre";
            // 
            // maaş_text
            // 
            this.maaş_text.Location = new System.Drawing.Point(143, 192);
            this.maaş_text.Name = "maaş_text";
            this.maaş_text.Size = new System.Drawing.Size(100, 20);
            this.maaş_text.TabIndex = 7;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.label3.Location = new System.Drawing.Point(87, 194);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(45, 18);
            this.label3.TabIndex = 6;
            this.label3.Text = "Maaş";
            // 
            // adsoyad_text
            // 
            this.adsoyad_text.Location = new System.Drawing.Point(143, 139);
            this.adsoyad_text.Name = "adsoyad_text";
            this.adsoyad_text.Size = new System.Drawing.Size(100, 20);
            this.adsoyad_text.TabIndex = 5;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label4.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.label4.Location = new System.Drawing.Point(68, 139);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(69, 18);
            this.label4.TabIndex = 4;
            this.label4.Text = "Ad soyad";
            // 
            // meslek_text
            // 
            this.meslek_text.Location = new System.Drawing.Point(143, 242);
            this.meslek_text.Name = "meslek_text";
            this.meslek_text.Size = new System.Drawing.Size(100, 20);
            this.meslek_text.TabIndex = 9;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label5.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.label5.Location = new System.Drawing.Point(76, 244);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(56, 18);
            this.label5.TabIndex = 8;
            this.label5.Text = "Meslek";
            // 
            // svg_text
            // 
            this.svg_text.Location = new System.Drawing.Point(143, 294);
            this.svg_text.Multiline = true;
            this.svg_text.Name = "svg_text";
            this.svg_text.Size = new System.Drawing.Size(120, 51);
            this.svg_text.TabIndex = 11;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label6.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.label6.Location = new System.Drawing.Point(7, 294);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(122, 18);
            this.label6.TabIndex = 10;
            this.label6.Text = "Son verilen görev";
            // 
            // kaydet_btn
            // 
            this.kaydet_btn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(43)))), ((int)(((byte)(46)))));
            this.kaydet_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.kaydet_btn.ForeColor = System.Drawing.Color.SlateGray;
            this.kaydet_btn.Location = new System.Drawing.Point(150, 373);
            this.kaydet_btn.Name = "kaydet_btn";
            this.kaydet_btn.Size = new System.Drawing.Size(93, 27);
            this.kaydet_btn.TabIndex = 12;
            this.kaydet_btn.Text = "Kaydet";
            this.kaydet_btn.UseVisualStyleBackColor = false;
            this.kaydet_btn.Click += new System.EventHandler(this.kaydet_btn_Click);
            // 
            // Güncelle_btn
            // 
            this.Güncelle_btn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(43)))), ((int)(((byte)(46)))));
            this.Güncelle_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.Güncelle_btn.ForeColor = System.Drawing.Color.SlateGray;
            this.Güncelle_btn.Location = new System.Drawing.Point(150, 416);
            this.Güncelle_btn.Name = "Güncelle_btn";
            this.Güncelle_btn.Size = new System.Drawing.Size(93, 27);
            this.Güncelle_btn.TabIndex = 13;
            this.Güncelle_btn.Text = "Güncelle";
            this.Güncelle_btn.UseVisualStyleBackColor = false;
            this.Güncelle_btn.Click += new System.EventHandler(this.Güncelle_btn_Click);
            // 
            // silincek_text
            // 
            this.silincek_text.Location = new System.Drawing.Point(418, 156);
            this.silincek_text.Name = "silincek_text";
            this.silincek_text.Size = new System.Drawing.Size(100, 20);
            this.silincek_text.TabIndex = 15;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label7.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.label7.Location = new System.Drawing.Point(378, 156);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(22, 18);
            this.label7.TabIndex = 14;
            this.label7.Text = "ID";
            // 
            // Sil
            // 
            this.Sil.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(43)))), ((int)(((byte)(46)))));
            this.Sil.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.Sil.ForeColor = System.Drawing.Color.SlateGray;
            this.Sil.Location = new System.Drawing.Point(424, 205);
            this.Sil.Name = "Sil";
            this.Sil.Size = new System.Drawing.Size(93, 27);
            this.Sil.TabIndex = 16;
            this.Sil.Text = "Sil";
            this.Sil.UseVisualStyleBackColor = false;
            this.Sil.Click += new System.EventHandler(this.Sil_Click);
            // 
            // çıkış
            // 
            this.çıkış.AutoSize = true;
            this.çıkış.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.çıkış.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.çıkış.Location = new System.Drawing.Point(0, 0);
            this.çıkış.Name = "çıkış";
            this.çıkış.Size = new System.Drawing.Size(18, 18);
            this.çıkış.TabIndex = 17;
            this.çıkış.Text = "X";
            this.çıkış.Click += new System.EventHandler(this.çıkış_Click);
            this.çıkış.MouseLeave += new System.EventHandler(this.çıkış_MouseLeave);
            this.çıkış.MouseMove += new System.Windows.Forms.MouseEventHandler(this.çıkış_MouseMove);
            // 
            // çalışanlar_düzenle
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(45)))), ((int)(((byte)(48)))));
            this.ClientSize = new System.Drawing.Size(622, 475);
            this.Controls.Add(this.çıkış);
            this.Controls.Add(this.Sil);
            this.Controls.Add(this.silincek_text);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.Güncelle_btn);
            this.Controls.Add(this.kaydet_btn);
            this.Controls.Add(this.svg_text);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.meslek_text);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.maaş_text);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.adsoyad_text);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.şifre_text);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Id_text);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "çalışanlar_düzenle";
            this.Text = "çalışanlar_düzenle";
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.çalışanlar_düzenle_MouseDown);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.çalışanlar_düzenle_MouseMove);
            this.MouseUp += new System.Windows.Forms.MouseEventHandler(this.çalışanlar_düzenle_MouseUp);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox Id_text;
        private System.Windows.Forms.TextBox şifre_text;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox maaş_text;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox adsoyad_text;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox meslek_text;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox svg_text;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button kaydet_btn;
        private System.Windows.Forms.Button Güncelle_btn;
        private System.Windows.Forms.TextBox silincek_text;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button Sil;
        private System.Windows.Forms.Label çıkış;
    }
}