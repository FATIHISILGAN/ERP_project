﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace deneme_erp
{
    public partial class Form1 : Form
    {
        SqlConnection bağlantı = new SqlConnection("Data Source=DESKTOP-JUST06P\\MSSQLSERVER01;Initial Catalog=ERP_iki; Integrated Security=True;");

        public Form1()
        {
            InitializeComponent();
        }
        public void görüntüle(string veri)
        {
            SqlDataAdapter DA = new SqlDataAdapter(veri, bağlantı);
            DataSet DS = new DataSet();
            DA.Fill(DS);

            dataGridView1.DataSource = DS.Tables[0];


        }
        public void görüntüle2(string veri)
        {
            SqlDataAdapter DA = new SqlDataAdapter(veri, bağlantı);
            DataSet DS = new DataSet();
            DA.Fill(DS);

            dataGridView2.DataSource = DS.Tables[0];


        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: Bu kod satırı 'eRP_ikiDataSet1.satış' tablosuna veri yükler. Bunu gerektiği şekilde taşıyabilir, veya kaldırabilirsiniz.
            this.satışTableAdapter.Fill(this.eRP_ikiDataSet1.satış);
            // TODO: Bu kod satırı 'eRP_ikiDataSet.Stok' tablosuna veri yükler. Bunu gerektiği şekilde taşıyabilir, veya kaldırabilirsiniz.
            this.stokTableAdapter.Fill(this.eRP_ikiDataSet.Stok);
            görüntüle("select *from stok");
            görüntüle2("select*from satış");
            
        }
    }
}
