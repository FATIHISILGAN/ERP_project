﻿namespace deneme_erp
{
    partial class Form1
    {
        /// <summary>
        ///Gerekli tasarımcı değişkeni.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///Kullanılan tüm kaynakları temizleyin.
        /// </summary>
        ///<param name="disposing">yönetilen kaynaklar dispose edilmeliyse doğru; aksi halde yanlış.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer üretilen kod

        /// <summary>
        /// Tasarımcı desteği için gerekli metot - bu metodun 
        ///içeriğini kod düzenleyici ile değiştirmeyin.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea2 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend2 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series2 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Title title1 = new System.Windows.Forms.DataVisualization.Charting.Title();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.chart1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.eRP_ikiDataSet = new deneme_erp.ERP_ikiDataSet();
            this.stokBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.stokTableAdapter = new deneme_erp.ERP_ikiDataSetTableAdapters.StokTableAdapter();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.eRP_ikiDataSet1 = new deneme_erp.ERP_ikiDataSet1();
            this.satışBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.satışTableAdapter = new deneme_erp.ERP_ikiDataSet1TableAdapters.satışTableAdapter();
            this.chart2 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.eRP_ikiDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.stokBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.eRP_ikiDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.satışBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart2)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(12, 45);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(410, 209);
            this.dataGridView1.TabIndex = 0;
            // 
            // chart1
            // 
            this.chart1.BackColor = System.Drawing.Color.Silver;
            chartArea1.Name = "ChartArea1";
            this.chart1.ChartAreas.Add(chartArea1);
            this.chart1.DataSource = this.satışBindingSource;
            legend1.Name = "Legend1";
            this.chart1.Legends.Add(legend1);
            this.chart1.Location = new System.Drawing.Point(428, 273);
            this.chart1.Name = "chart1";
            series1.ChartArea = "ChartArea1";
            series1.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Area;
            series1.Legend = "Legend1";
            series1.Name = "Tarihe göre satış";
            series1.XValueMember = "satış_tarihi";
            series1.YValueMembers = "satış_adet";
            this.chart1.Series.Add(series1);
            this.chart1.Size = new System.Drawing.Size(443, 209);
            this.chart1.TabIndex = 1;
            this.chart1.Text = "chart1";
            // 
            // eRP_ikiDataSet
            // 
            this.eRP_ikiDataSet.DataSetName = "ERP_ikiDataSet";
            this.eRP_ikiDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // stokBindingSource
            // 
            this.stokBindingSource.DataMember = "Stok";
            this.stokBindingSource.DataSource = this.eRP_ikiDataSet;
            // 
            // stokTableAdapter
            // 
            this.stokTableAdapter.ClearBeforeFill = true;
            // 
            // dataGridView2
            // 
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(12, 273);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.Size = new System.Drawing.Size(410, 209);
            this.dataGridView2.TabIndex = 3;
            // 
            // eRP_ikiDataSet1
            // 
            this.eRP_ikiDataSet1.DataSetName = "ERP_ikiDataSet1";
            this.eRP_ikiDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // satışBindingSource
            // 
            this.satışBindingSource.DataMember = "satış";
            this.satışBindingSource.DataSource = this.eRP_ikiDataSet1;
            // 
            // satışTableAdapter
            // 
            this.satışTableAdapter.ClearBeforeFill = true;
            // 
            // chart2
            // 
            this.chart2.BackColor = System.Drawing.Color.Silver;
            chartArea2.Name = "ChartArea1";
            this.chart2.ChartAreas.Add(chartArea2);
            this.chart2.DataSource = this.stokBindingSource;
            legend2.Name = "Legend1";
            this.chart2.Legends.Add(legend2);
            this.chart2.Location = new System.Drawing.Point(428, 45);
            this.chart2.Name = "chart2";
            series2.ChartArea = "ChartArea1";
            series2.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Pie;
            series2.Legend = "Legend1";
            series2.Name = "En çok satanlar";
            series2.XValueMember = "ürün_ad";
            series2.YValueMembers = "ürün_toplam_satılma";
            this.chart2.Series.Add(series2);
            this.chart2.Size = new System.Drawing.Size(443, 209);
            this.chart2.TabIndex = 4;
            this.chart2.Text = "dfffdfdf";
            title1.Name = "Title1";
            title1.Text = "Ürünlerin satış oranı";
            this.chart2.Titles.Add(title1);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(45)))), ((int)(((byte)(48)))));
            this.ClientSize = new System.Drawing.Size(905, 539);
            this.Controls.Add(this.chart2);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.chart1);
            this.Controls.Add(this.dataGridView1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.eRP_ikiDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.stokBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.eRP_ikiDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.satışBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart1;
        private ERP_ikiDataSet eRP_ikiDataSet;
        private System.Windows.Forms.BindingSource stokBindingSource;
        private ERP_ikiDataSetTableAdapters.StokTableAdapter stokTableAdapter;
        private System.Windows.Forms.DataGridView dataGridView2;
        private ERP_ikiDataSet1 eRP_ikiDataSet1;
        private System.Windows.Forms.BindingSource satışBindingSource;
        private ERP_ikiDataSet1TableAdapters.satışTableAdapter satışTableAdapter;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart2;
    }
}

