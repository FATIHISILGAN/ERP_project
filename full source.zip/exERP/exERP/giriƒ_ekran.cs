﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace exERP
{
    public partial class giriş_ekran : Form
    {
        SqlConnection bağlantı = new SqlConnection("Data Source=DESKTOP-JUST06P\\MSSQLSERVER01;Initial Catalog=ERP; Integrated Security=True;");


        bool dragging;

        Point offset;
        public giriş_ekran()
        {
            InitializeComponent();
        }



        public void giriş_kontrol()
        {
            try
            {
                bağlantı.Open();
                string komut = "select *from yönetici_bilgi where İD=@id AND şifr" + "e=@şifRe";

                SqlParameter sqlParameter = new SqlParameter("id", textBox1.Text.Trim());
                SqlParameter sqlparameter2 = new SqlParameter("şifre", textBox2.Text.Trim());
                SqlCommand sc = new SqlCommand(komut, bağlantı);
                sc.Parameters.Add(sqlParameter);
                sc.Parameters.Add(sqlparameter2);
                DataTable dt = new DataTable();

                SqlDataAdapter sda = new SqlDataAdapter(sc);

                sda.Fill(dt);


                if (dt.Rows.Count > 0)
                {
                    Yönetici_I yı = new Yönetici_I();

                    yı.Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("id veya şifre yanlış");
                }




                bağlantı.Close();


            }
            catch (Exception m)
            {
                MessageBox.Show("bir sorun oluştu");

                MessageBox.Show(m.Message);

            }
        }

        private void giriş_ekran_MouseMove(object sender, MouseEventArgs e)
        {
            if (dragging)
            {
                Point currentScreenPos = PointToScreen(e.Location);
                Location = new
                Point(currentScreenPos.X - offset.X,
                currentScreenPos.Y - offset.Y);
            }
        }

        private void giriş_ekran_MouseUp(object sender, MouseEventArgs e)
        {
            dragging = false;
        }

        private void giriş_ekran_MouseDown(object sender, MouseEventArgs e)
        {

            dragging = true;
            offset = e.Location;
        }

        private void Giriş_btn_Click(object sender, EventArgs e)
        {
            giriş_kontrol();
        }

       

        private void panel1_MouseMove(object sender, MouseEventArgs e)
        {
            panel1.BackColor = Color.IndianRed;
        }

        private void panel1_MouseLeave(object sender, EventArgs e)
        {
            panel1.BackColor = Color.FromArgb(45, 45, 48);
        }

        private void label3_MouseMove(object sender, MouseEventArgs e)
        {
            panel1.BackColor = Color.IndianRed;
            
        }

        private void label3_MouseLeave(object sender, EventArgs e)
        {
            panel1.BackColor = Color.FromArgb(45, 45, 48);
        }

        private void label3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void panel1_MouseClick(object sender, MouseEventArgs e)
        {
            this.Close();
        }

        private void giriş_ekran_Load(object sender, EventArgs e)
        {
            
            textBox2.UseSystemPasswordChar = true;

        }

        private void textBox1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                giriş_kontrol();
            }
        }

        private void textBox2_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                giriş_kontrol();
            }
        }
    }
    }

