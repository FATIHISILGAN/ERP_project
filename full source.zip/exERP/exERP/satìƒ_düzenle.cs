﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace exERP
{
    public partial class satış_düzenle : Form
    {
        SqlConnection bağlantı = new SqlConnection("Data Source=DESKTOP-JUST06P\\MSSQLSERVER01;Initial Catalog=ERP; Integrated Security=True;");
        public satış_düzenle()
        {
            InitializeComponent();
        }
        bool dragging;

        Point offset;
        private void satış_düzenle_MouseMove(object sender, MouseEventArgs e)
        {
            if (dragging)
            {
                Point currentScreenPos = PointToScreen(e.Location);
                Location = new
                Point(currentScreenPos.X - offset.X,
                currentScreenPos.Y - offset.Y);
            }
        }

        private void satış_düzenle_MouseUp(object sender, MouseEventArgs e)
        {
            dragging = false;
        }

        private void satış_düzenle_MouseDown(object sender, MouseEventArgs e)
        {

            dragging = true;
            offset = e.Location;
        }

        private void ekle_btn_Click(object sender, EventArgs e)
        {
            bağlantı.Open();

            SqlCommand komut = new SqlCommand("insert into satış(satış_id,ürün_id,tarih,satış_adet)values(@id,@üid,@tarih,@adet)", bağlantı);

            komut.Parameters.AddWithValue("@id", id_txt.Text);
            komut.Parameters.AddWithValue("@üid", ürün_id.Text);
            komut.Parameters.AddWithValue("@tarih", tarih.Text);
            komut.Parameters.AddWithValue("@adet", adet_txt.Text);



            komut.ExecuteNonQuery();

            bağlantı.Close();

            MessageBox.Show("başarı ile eklendi yenile düğmesine basmayı unutmayınız");

            this.Hide();
        }

        private void sil_btn_Click(object sender, EventArgs e)
        {
            bağlantı.Open();
            SqlCommand komut = new SqlCommand("delete from satış where satış_id=@id", bağlantı);
            komut.Parameters.AddWithValue("@id", sil_id.Text);
            komut.ExecuteNonQuery();
            bağlantı.Close();

            MessageBox.Show("başarı ile silindi yenile düğmesine basmayı unutmayınız");

            this.Hide();
        }

        private void güncelle_btn_Click(object sender, EventArgs e)
        {
            string format = "yyyy-MM-dd";
            
            bağlantı.Open();
            SqlCommand komut = new SqlCommand("update satış set ürün_id= '" + ürün_id.Text + "',tarih='" + tarih.Text +"',satış_adet='"+adet_txt.Text+"' where satış_id= '" + id_txt.Text + " '", bağlantı);
            komut.ExecuteNonQuery();
            MessageBox.Show("başarı ile güncellendi yenile düğmesine basmayı unutmayınız");

        }

        private void label5_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void label5_MouseLeave(object sender, EventArgs e)
        {
            label5.BackColor = Color.FromArgb(45, 45, 48);

        }

        private void label5_MouseMove(object sender, MouseEventArgs e)
        {
            label5.BackColor = Color.IndianRed;


        }
    }
}
