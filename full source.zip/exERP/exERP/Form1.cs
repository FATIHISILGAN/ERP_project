﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace exERP
{

    public partial class Yönetici_I : Form
    {
        SqlConnection bağlantı = new SqlConnection("Data Source=DESKTOP-JUST06P\\MSSQLSERVER01;Initial Catalog=ERP; Integrated Security=True;");

        public void görüntüle(string veri)
        {
            SqlDataAdapter DA = new SqlDataAdapter(veri,bağlantı);
            DataSet DS = new DataSet();
            DA.Fill(DS);

            db_görüntüleyici.DataSource = DS.Tables[0];


        }

      
        bool dragging;

        Point offset;

        bool çalışanbl, stokbl, satışbl;

        public Yönetici_I()
        {
            InitializeComponent();
        }

        private void Yönetici_I_MouseDown(object sender, MouseEventArgs e)
        {
            dragging = true;
            offset = e.Location;
        }

        private void Yönetici_I_MouseUp(object sender, MouseEventArgs e)
        {
            dragging = false;
        }

        private void Yönetici_I_MouseMove(object sender, MouseEventArgs e)
        {
            if(dragging)
{
                Point currentScreenPos = PointToScreen(e.Location);
                Location = new
                Point(currentScreenPos.X - offset.X,
                currentScreenPos.Y - offset.Y);
            }
        }

        private void Yönetici_I_Load(object sender, EventArgs e)
        {

         




            /*-----------------------------*/










        }

        private void anasayfa_panel_MouseMove(object sender, MouseEventArgs e)
        {
            anasayfa_panel.BackColor = Color.FromArgb(60, 60, 40);
        }

        private void anasayfa_panel_MouseLeave(object sender, EventArgs e)
        {
            anasayfa_panel.BackColor = Color.FromArgb(43, 43, 46);
        }

        private void anasayfa_pic_box_MouseMove(object sender, MouseEventArgs e)
        {
            anasayfa_panel.BackColor = Color.FromArgb(60, 60, 40);
        }

        private void anasayfa_pic_box_MouseLeave(object sender, EventArgs e)
        {
            anasayfa_panel.BackColor = Color.FromArgb(43, 43, 46);
        }

        private void anasayfa_lbl_MouseMove(object sender, MouseEventArgs e)
        {
            anasayfa_panel.BackColor = Color.FromArgb(60, 60, 40);
        }

        private void anasayfa_lbl_MouseLeave(object sender, EventArgs e)
        {
            anasayfa_panel.BackColor = Color.FromArgb(43, 43, 46);
        }

        private void çalışanlar_panel_MouseDown(object sender, MouseEventArgs e)
        {
            çalışanlar_panel.BackColor = Color.FromArgb(60, 60, 40);
        }

        private void çalışanlar_panel_MouseLeave(object sender, EventArgs e)
        {
            çalışanlar_panel.BackColor = Color.FromArgb(43, 43, 46);
        }

        private void çalışanlar_pic_box_MouseMove(object sender, MouseEventArgs e)
        {
            çalışanlar_panel.BackColor = Color.FromArgb(60, 60, 40);
        }

        private void çalışanlar_lbl_MouseMove(object sender, MouseEventArgs e)
        {
            çalışanlar_panel.BackColor = Color.FromArgb(60, 60, 40);
        }

        private void çalışanlar_pic_box_MouseLeave(object sender, EventArgs e)
        {
            çalışanlar_panel.BackColor = Color.FromArgb(60, 60, 40);
        }

        private void çalışanlar_lbl_MouseLeave(object sender, EventArgs e)
        {
            çalışanlar_panel.BackColor = Color.FromArgb(43, 43, 46);
        }

        private void stok_pic_box_MouseMove(object sender, MouseEventArgs e)
        {
            stok_panel.BackColor = Color.FromArgb(60, 60, 40);
        }

        private void stok_pic_box_MouseLeave(object sender, EventArgs e)
        {
            stok_panel.BackColor = Color.FromArgb(43, 43, 46);
        }

        private void stok_lbl_MouseMove(object sender, MouseEventArgs e)
        {
            stok_panel.BackColor = Color.FromArgb(60, 60, 40);
        }

        private void stok_lbl_MouseLeave(object sender, EventArgs e)
        {
            stok_panel.BackColor = Color.FromArgb(43, 43, 46);
        }

        private void stok_panel_MouseMove(object sender, MouseEventArgs e)
        {
            stok_panel.BackColor = Color.FromArgb(60, 60, 40);
        }

        private void stok_panel_MouseLeave(object sender, EventArgs e)
        {
            stok_panel.BackColor = Color.FromArgb(43, 43, 46);
        }

        private void geri_bildirim_panel_MouseMove(object sender, MouseEventArgs e)
        {
            geri_bildirim_panel.BackColor = Color.FromArgb(60, 60, 40);
        }

        private void geri_bildirim_panel_MouseLeave(object sender, EventArgs e)
        {
            geri_bildirim_panel.BackColor = Color.FromArgb(43, 43, 46);

        }

        private void geri_bildirim_pic_box_MouseMove(object sender, MouseEventArgs e)
        {
            geri_bildirim_panel.BackColor = Color.FromArgb(60, 60, 40);
        }

        private void geri_bildirim_pic_box_MouseLeave(object sender, EventArgs e)
        {
            geri_bildirim_panel.BackColor = Color.FromArgb(43, 43, 46);
        }

        private void geri_bildirim_lbl_MouseMove(object sender, MouseEventArgs e)
        {
            geri_bildirim_panel.BackColor = Color.FromArgb(60, 60, 40);
        }

        private void geri_bildirim_lbl_MouseLeave(object sender, EventArgs e)
        {
            geri_bildirim_panel.BackColor = Color.FromArgb(43, 43, 46);
        }

        private void alt_panel_MouseMove(object sender, MouseEventArgs e)
        {
            if (dragging)
            {
                Point currentScreenPos = PointToScreen(e.Location);
                Location = new
                Point(currentScreenPos.X - offset.X,
                currentScreenPos.Y - offset.Y);
            }
        }

        private void alt_panel_MouseUp(object sender, MouseEventArgs e)
        {
            dragging = false;
        }

        private void alt_panel_MouseDown(object sender, MouseEventArgs e)
        {
            dragging = true;
            offset = e.Location;
        }

        private void logo_pic_box_MouseMove(object sender, MouseEventArgs e)
        {
            if (dragging)
            {
                Point currentScreenPos = PointToScreen(e.Location);
                Location = new
                Point(currentScreenPos.X - offset.X,
                currentScreenPos.Y - offset.Y);
            }
        }

        private void logo_pic_box_MouseUp(object sender, MouseEventArgs e)
        {
            dragging = false;
        }

        private void logo_pic_box_MouseDown(object sender, MouseEventArgs e)
        {
            dragging = true;
            offset = e.Location;
        }

        private void sol_panel_MouseDown(object sender, MouseEventArgs e)
        {
            dragging = true;
            offset = e.Location;
        }

        private void sol_panel_MouseUp(object sender, MouseEventArgs e)
        {
            dragging = false;
        }

        private void sol_panel_MouseMove(object sender, MouseEventArgs e)
        {
            if (dragging)
            {
                Point currentScreenPos = PointToScreen(e.Location);
                Location = new
                Point(currentScreenPos.X - offset.X,
                currentScreenPos.Y - offset.Y);
            }
        }

        private void çalışanlar_pic_box_Click(object sender, EventArgs e)
        {
            çalışanbl = true;
            stokbl = false;
            satışbl = false;
            db_görüntüleyici.Visible = true;
            satış.Visible = false;
            çalışan_maaş.Visible = false;
            en_çok_satılan.Visible = false;
            düzenle_btn.Visible = true;
            btn_yenile.Visible = true;
            görüntüle("Select * From çalışanlar");

        }

        private void çalışanlar_lbl_Click(object sender, EventArgs e)
        {
            çalışanbl = true;
            stokbl = false;
            satışbl = false;
            db_görüntüleyici.Visible = true;
            satış.Visible = false;
            çalışan_maaş.Visible = false;
            en_çok_satılan.Visible = false;
            düzenle_btn.Visible = true;
            btn_yenile.Visible = true;
            görüntüle("Select * From çalışanlar");
        }

        private void çalışanlar_panel_Click(object sender, EventArgs e)
        {
            çalışanbl = true;
            stokbl = false;
            satışbl = false;
            db_görüntüleyici.Visible = true;
            satış.Visible = false;
            çalışan_maaş.Visible = false;
            en_çok_satılan.Visible = false;
            düzenle_btn.Visible = true;
            btn_yenile.Visible = true;
            görüntüle("Select * From çalışanlar");
        }

        private void anasayfa_panel_MouseClick(object sender, MouseEventArgs e)
        {
            db_görüntüleyici.Visible = false;
            satış.Visible = true;
            çalışan_maaş.Visible = true;
            en_çok_satılan.Visible = true;
            düzenle_btn.Visible =false;
            btn_yenile.Visible = false;
        }

        private void anasayfa_pic_box_Click(object sender, EventArgs e)
        {
            db_görüntüleyici.Visible = false;
            satış.Visible = true;
            çalışan_maaş.Visible = true;
            en_çok_satılan.Visible = true;
            düzenle_btn.Visible = false;
            btn_yenile.Visible = false;
            
        }

        private void anasayfa_lbl_Click(object sender, EventArgs e)
        {
            db_görüntüleyici.Visible = false;
            satış.Visible = true;
            çalışan_maaş.Visible = true;
            en_çok_satılan.Visible = true;
            düzenle_btn.Visible =false;
            btn_yenile.Visible = false;
        }

        private void düzenle_btn_Click(object sender, EventArgs e)
        {
            if (çalışanbl == true)
            {
                çalışanlar_düzenle_Form frm = new çalışanlar_düzenle_Form();
                frm.Show();
            }
            else if (stokbl == true)
            {
                stok_düzenle std = new stok_düzenle();
                std.Show();
            }
            else if (satışbl == true)
            {
                satış_düzenle satışdüzenle = new satış_düzenle();

                satışdüzenle.Show();

            }
        }

        private void btn_yenile_Click(object sender, EventArgs e)
        {
            if (çalışanbl == true)
            {
                görüntüle("Select *From çalışanlar");
            }
            else if (stokbl == true)
            {
                görüntüle("Select *From stok");
            }
            else if(satışbl == true)
            {
                görüntüle("Select *From satış");
                


            }
        }

        private void stok_pic_box_Click(object sender, EventArgs e)
        {
            çalışanbl = false;
            stokbl = true;
            satışbl = false;
            db_görüntüleyici.Visible = true;
            satış.Visible = false;
            çalışan_maaş.Visible = false;
            en_çok_satılan.Visible = false;
            düzenle_btn.Visible = true;
            btn_yenile.Visible = true;
            görüntüle("Select * From stok");
        }

        private void geri_bildirim_lbl_Click(object sender, EventArgs e)
        {
            çalışanbl = false;
            stokbl = false;
            satışbl = true;
            db_görüntüleyici.Visible = true;
            satış.Visible = false;
            çalışan_maaş.Visible = false;
            en_çok_satılan.Visible = false;
            düzenle_btn.Visible = true;
            btn_yenile.Visible = true;

            görüntüle("Select * From satış");

        }

        private void geri_bildirim_pic_box_Click(object sender, EventArgs e)
        {
            çalışanbl = false;
            stokbl = false;
            satışbl = true;
            db_görüntüleyici.Visible = true;
            satış.Visible = false;
            çalışan_maaş.Visible = false;
            en_çok_satılan.Visible = false;
            düzenle_btn.Visible = true;
            btn_yenile.Visible = true;

            görüntüle("Select * From satış");
        }

        private void geri_bildirim_panel_MouseClick(object sender, MouseEventArgs e)
        {
            çalışanbl = false;
            stokbl = false;
            satışbl = true;
            db_görüntüleyici.Visible = true;
            satış.Visible = false;
            çalışan_maaş.Visible = false;
            en_çok_satılan.Visible = false;
            düzenle_btn.Visible = true;
            btn_yenile.Visible = true;
            görüntüle("Select * From satış");
        }

        private void label3_MouseMove(object sender, MouseEventArgs e)
        {
           label3.BackColor = Color.IndianRed;
        }

        private void label3_MouseLeave(object sender, EventArgs e)
        {
            label3.BackColor = Color.FromArgb(45, 45, 48);

        }

        private void label3_MouseClick(object sender, MouseEventArgs e)
        {
            this.Close();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
          


        }

        private void Yönetici_I_Load_1(object sender, EventArgs e)
        {
            // TODO: Bu kod satırı 'eRPDataSet2.çalışanlar' tablosuna veri yükler. Bunu gerektiği şekilde taşıyabilir, veya kaldırabilirsiniz.
            this.çalışanlarTableAdapter.Fill(this.eRPDataSet2.çalışanlar);
            // TODO: Bu kod satırı 'eRPDataSet1.satış' tablosuna veri yükler. Bunu gerektiği şekilde taşıyabilir, veya kaldırabilirsiniz.
            this.satışTableAdapter1.Fill(this.eRPDataSet1.satış);
            // TODO: Bu kod satırı 'eRPDataSet.satış' tablosuna veri yükler. Bunu gerektiği şekilde taşıyabilir, veya kaldırabilirsiniz.
            this.satışTableAdapter.Fill(this.eRPDataSet.satış);
            db_görüntüleyici.Visible = false;
            düzenle_btn.Visible = false;
            btn_yenile.Visible = false;

        }

        private void stok_panel_MouseClick(object sender, MouseEventArgs e)
        {
            çalışanbl = false;
            stokbl = true;
            satışbl = false;
            db_görüntüleyici.Visible = true;
            satış.Visible = false;
            çalışan_maaş.Visible = false;
            en_çok_satılan.Visible = false;
            düzenle_btn.Visible = true;
            btn_yenile.Visible = true;
            görüntüle("Select * From stok");
        }

        private void stok_lbl_Click(object sender, EventArgs e)
        {
            çalışanbl = false;
            stokbl = true;
            satışbl = false;
            db_görüntüleyici.Visible = true;
            satış.Visible = false;
            çalışan_maaş.Visible = false;
            en_çok_satılan.Visible = false;
            düzenle_btn.Visible = true;
            btn_yenile.Visible = true;
            görüntüle("Select * From stok");
        }
    }
}
