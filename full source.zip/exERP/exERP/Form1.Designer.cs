﻿namespace exERP
{
    partial class Yönetici_I
    {
        /// <summary>
        ///Gerekli tasarımcı değişkeni.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///Kullanılan tüm kaynakları temizleyin.
        /// </summary>
        ///<param name="disposing">yönetilen kaynaklar dispose edilmeliyse doğru; aksi halde yanlış.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer üretilen kod

        /// <summary>
        /// Tasarımcı desteği için gerekli metot - bu metodun 
        ///içeriğini kod düzenleyici ile değiştirmeyin.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea16 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend16 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series16 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.DataPoint dataPoint36 = new System.Windows.Forms.DataVisualization.Charting.DataPoint(0D, 0D);
            System.Windows.Forms.DataVisualization.Charting.DataPoint dataPoint37 = new System.Windows.Forms.DataVisualization.Charting.DataPoint(0D, 0D);
            System.Windows.Forms.DataVisualization.Charting.DataPoint dataPoint38 = new System.Windows.Forms.DataVisualization.Charting.DataPoint(0D, 0D);
            System.Windows.Forms.DataVisualization.Charting.DataPoint dataPoint39 = new System.Windows.Forms.DataVisualization.Charting.DataPoint(0D, 0D);
            System.Windows.Forms.DataVisualization.Charting.DataPoint dataPoint40 = new System.Windows.Forms.DataVisualization.Charting.DataPoint(0D, 0D);
            System.Windows.Forms.DataVisualization.Charting.DataPoint dataPoint41 = new System.Windows.Forms.DataVisualization.Charting.DataPoint(0D, 0D);
            System.Windows.Forms.DataVisualization.Charting.DataPoint dataPoint42 = new System.Windows.Forms.DataVisualization.Charting.DataPoint(0D, 0D);
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea17 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend17 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series17 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea18 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend18 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.LegendCellColumn legendCellColumn6 = new System.Windows.Forms.DataVisualization.Charting.LegendCellColumn();
            System.Windows.Forms.DataVisualization.Charting.Series series18 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.sol_panel = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.geri_bildirim_lbl = new System.Windows.Forms.Label();
            this.stok_lbl = new System.Windows.Forms.Label();
            this.geri_bildirim_pic_box = new System.Windows.Forms.PictureBox();
            this.çalışanlar_lbl = new System.Windows.Forms.Label();
            this.stok_pic_box = new System.Windows.Forms.PictureBox();
            this.çalışanlar_pic_box = new System.Windows.Forms.PictureBox();
            this.anasayfa_lbl = new System.Windows.Forms.Label();
            this.anasayfa_pic_box = new System.Windows.Forms.PictureBox();
            this.logo_pic_box = new System.Windows.Forms.PictureBox();
            this.anasayfa_panel = new System.Windows.Forms.Panel();
            this.çalışanlar_panel = new System.Windows.Forms.Panel();
            this.geri_bildirim_panel = new System.Windows.Forms.Panel();
            this.stok_panel = new System.Windows.Forms.Panel();
            this.alt_panel = new System.Windows.Forms.Panel();
            this.btn_yenile = new System.Windows.Forms.Button();
            this.düzenle_btn = new System.Windows.Forms.Button();
            this.db_görüntüleyici = new System.Windows.Forms.DataGridView();
            this.çalışan_maaş = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.çalışanlarBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.eRPDataSet2 = new exERP.ERPDataSet2();
            this.en_çok_satılan = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.satışBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.eRPDataSet1 = new exERP.ERPDataSet1();
            this.satış = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.satışBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.eRPDataSet = new exERP.ERPDataSet();
            this.satışTableAdapter = new exERP.ERPDataSetTableAdapters.satışTableAdapter();
            this.satışTableAdapter1 = new exERP.ERPDataSet1TableAdapters.satışTableAdapter();
            this.eRPDataSet1BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.çalışanlarTableAdapter = new exERP.ERPDataSet2TableAdapters.çalışanlarTableAdapter();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.sol_panel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.geri_bildirim_pic_box)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.stok_pic_box)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.çalışanlar_pic_box)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.anasayfa_pic_box)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.logo_pic_box)).BeginInit();
            this.alt_panel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.db_görüntüleyici)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.çalışan_maaş)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.çalışanlarBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.eRPDataSet2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.en_çok_satılan)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.satışBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.eRPDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.satış)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.satışBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.eRPDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.eRPDataSet1BindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // sol_panel
            // 
            this.sol_panel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(43)))), ((int)(((byte)(46)))));
            this.sol_panel.Controls.Add(this.label3);
            this.sol_panel.Controls.Add(this.geri_bildirim_lbl);
            this.sol_panel.Controls.Add(this.stok_lbl);
            this.sol_panel.Controls.Add(this.geri_bildirim_pic_box);
            this.sol_panel.Controls.Add(this.çalışanlar_lbl);
            this.sol_panel.Controls.Add(this.stok_pic_box);
            this.sol_panel.Controls.Add(this.çalışanlar_pic_box);
            this.sol_panel.Controls.Add(this.anasayfa_lbl);
            this.sol_panel.Controls.Add(this.anasayfa_pic_box);
            this.sol_panel.Controls.Add(this.logo_pic_box);
            this.sol_panel.Controls.Add(this.anasayfa_panel);
            this.sol_panel.Controls.Add(this.çalışanlar_panel);
            this.sol_panel.Controls.Add(this.geri_bildirim_panel);
            this.sol_panel.Controls.Add(this.stok_panel);
            this.sol_panel.Location = new System.Drawing.Point(1, 1);
            this.sol_panel.Name = "sol_panel";
            this.sol_panel.Size = new System.Drawing.Size(173, 557);
            this.sol_panel.TabIndex = 0;
            this.sol_panel.MouseDown += new System.Windows.Forms.MouseEventHandler(this.sol_panel_MouseDown);
            this.sol_panel.MouseMove += new System.Windows.Forms.MouseEventHandler(this.sol_panel_MouseMove);
            this.sol_panel.MouseUp += new System.Windows.Forms.MouseEventHandler(this.sol_panel_MouseUp);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.label3.Location = new System.Drawing.Point(0, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(14, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "X";
            this.label3.MouseClick += new System.Windows.Forms.MouseEventHandler(this.label3_MouseClick);
            this.label3.MouseLeave += new System.EventHandler(this.label3_MouseLeave);
            this.label3.MouseMove += new System.Windows.Forms.MouseEventHandler(this.label3_MouseMove);
            // 
            // geri_bildirim_lbl
            // 
            this.geri_bildirim_lbl.AutoSize = true;
            this.geri_bildirim_lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.geri_bildirim_lbl.ForeColor = System.Drawing.Color.SlateGray;
            this.geri_bildirim_lbl.Location = new System.Drawing.Point(64, 520);
            this.geri_bildirim_lbl.Name = "geri_bildirim_lbl";
            this.geri_bildirim_lbl.Size = new System.Drawing.Size(46, 18);
            this.geri_bildirim_lbl.TabIndex = 7;
            this.geri_bildirim_lbl.Text = "Satış";
            this.geri_bildirim_lbl.Click += new System.EventHandler(this.geri_bildirim_lbl_Click);
            this.geri_bildirim_lbl.MouseLeave += new System.EventHandler(this.geri_bildirim_lbl_MouseLeave);
            this.geri_bildirim_lbl.MouseMove += new System.Windows.Forms.MouseEventHandler(this.geri_bildirim_lbl_MouseMove);
            // 
            // stok_lbl
            // 
            this.stok_lbl.AutoSize = true;
            this.stok_lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.stok_lbl.ForeColor = System.Drawing.Color.SlateGray;
            this.stok_lbl.Location = new System.Drawing.Point(67, 399);
            this.stok_lbl.Name = "stok_lbl";
            this.stok_lbl.Size = new System.Drawing.Size(43, 18);
            this.stok_lbl.TabIndex = 5;
            this.stok_lbl.Text = "Stok";
            this.stok_lbl.Click += new System.EventHandler(this.stok_lbl_Click);
            this.stok_lbl.MouseLeave += new System.EventHandler(this.stok_lbl_MouseLeave);
            this.stok_lbl.MouseMove += new System.Windows.Forms.MouseEventHandler(this.stok_lbl_MouseMove);
            // 
            // geri_bildirim_pic_box
            // 
            this.geri_bildirim_pic_box.Image = global::exERP.Properties.Resources.geri_bildirim;
            this.geri_bildirim_pic_box.Location = new System.Drawing.Point(37, 460);
            this.geri_bildirim_pic_box.Name = "geri_bildirim_pic_box";
            this.geri_bildirim_pic_box.Size = new System.Drawing.Size(100, 71);
            this.geri_bildirim_pic_box.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.geri_bildirim_pic_box.TabIndex = 8;
            this.geri_bildirim_pic_box.TabStop = false;
            this.geri_bildirim_pic_box.Click += new System.EventHandler(this.geri_bildirim_pic_box_Click);
            this.geri_bildirim_pic_box.MouseLeave += new System.EventHandler(this.geri_bildirim_pic_box_MouseLeave);
            this.geri_bildirim_pic_box.MouseMove += new System.Windows.Forms.MouseEventHandler(this.geri_bildirim_pic_box_MouseMove);
            // 
            // çalışanlar_lbl
            // 
            this.çalışanlar_lbl.AutoSize = true;
            this.çalışanlar_lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.çalışanlar_lbl.ForeColor = System.Drawing.Color.SlateGray;
            this.çalışanlar_lbl.Location = new System.Drawing.Point(44, 284);
            this.çalışanlar_lbl.Name = "çalışanlar_lbl";
            this.çalışanlar_lbl.Size = new System.Drawing.Size(83, 18);
            this.çalışanlar_lbl.TabIndex = 3;
            this.çalışanlar_lbl.Text = "Çalışanlar";
            this.çalışanlar_lbl.Click += new System.EventHandler(this.çalışanlar_lbl_Click);
            this.çalışanlar_lbl.MouseLeave += new System.EventHandler(this.çalışanlar_lbl_MouseLeave);
            this.çalışanlar_lbl.MouseMove += new System.Windows.Forms.MouseEventHandler(this.çalışanlar_lbl_MouseMove);
            // 
            // stok_pic_box
            // 
            this.stok_pic_box.Image = global::exERP.Properties.Resources.stok;
            this.stok_pic_box.Location = new System.Drawing.Point(37, 343);
            this.stok_pic_box.Name = "stok_pic_box";
            this.stok_pic_box.Size = new System.Drawing.Size(100, 71);
            this.stok_pic_box.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.stok_pic_box.TabIndex = 6;
            this.stok_pic_box.TabStop = false;
            this.stok_pic_box.Click += new System.EventHandler(this.stok_pic_box_Click);
            this.stok_pic_box.MouseLeave += new System.EventHandler(this.stok_pic_box_MouseLeave);
            this.stok_pic_box.MouseMove += new System.Windows.Forms.MouseEventHandler(this.stok_pic_box_MouseMove);
            // 
            // çalışanlar_pic_box
            // 
            this.çalışanlar_pic_box.Image = global::exERP.Properties.Resources.emp;
            this.çalışanlar_pic_box.Location = new System.Drawing.Point(36, 231);
            this.çalışanlar_pic_box.Name = "çalışanlar_pic_box";
            this.çalışanlar_pic_box.Size = new System.Drawing.Size(100, 71);
            this.çalışanlar_pic_box.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.çalışanlar_pic_box.TabIndex = 4;
            this.çalışanlar_pic_box.TabStop = false;
            this.çalışanlar_pic_box.Click += new System.EventHandler(this.çalışanlar_pic_box_Click);
            this.çalışanlar_pic_box.MouseLeave += new System.EventHandler(this.çalışanlar_pic_box_MouseLeave);
            this.çalışanlar_pic_box.MouseMove += new System.Windows.Forms.MouseEventHandler(this.çalışanlar_pic_box_MouseMove);
            // 
            // anasayfa_lbl
            // 
            this.anasayfa_lbl.AutoSize = true;
            this.anasayfa_lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.anasayfa_lbl.ForeColor = System.Drawing.Color.SlateGray;
            this.anasayfa_lbl.Location = new System.Drawing.Point(46, 164);
            this.anasayfa_lbl.Name = "anasayfa_lbl";
            this.anasayfa_lbl.Size = new System.Drawing.Size(76, 18);
            this.anasayfa_lbl.TabIndex = 2;
            this.anasayfa_lbl.Text = "Anasayfa";
            this.anasayfa_lbl.Click += new System.EventHandler(this.anasayfa_lbl_Click);
            this.anasayfa_lbl.MouseLeave += new System.EventHandler(this.anasayfa_lbl_MouseLeave);
            this.anasayfa_lbl.MouseMove += new System.Windows.Forms.MouseEventHandler(this.anasayfa_lbl_MouseMove);
            // 
            // anasayfa_pic_box
            // 
            this.anasayfa_pic_box.Image = global::exERP.Properties.Resources.home;
            this.anasayfa_pic_box.Location = new System.Drawing.Point(34, 111);
            this.anasayfa_pic_box.Name = "anasayfa_pic_box";
            this.anasayfa_pic_box.Size = new System.Drawing.Size(100, 71);
            this.anasayfa_pic_box.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.anasayfa_pic_box.TabIndex = 2;
            this.anasayfa_pic_box.TabStop = false;
            this.anasayfa_pic_box.Click += new System.EventHandler(this.anasayfa_pic_box_Click);
            this.anasayfa_pic_box.MouseLeave += new System.EventHandler(this.anasayfa_pic_box_MouseLeave);
            this.anasayfa_pic_box.MouseMove += new System.Windows.Forms.MouseEventHandler(this.anasayfa_pic_box_MouseMove);
            // 
            // logo_pic_box
            // 
            this.logo_pic_box.Image = global::exERP.Properties.Resources.Logo_ex;
            this.logo_pic_box.Location = new System.Drawing.Point(3, 0);
            this.logo_pic_box.Name = "logo_pic_box";
            this.logo_pic_box.Size = new System.Drawing.Size(170, 91);
            this.logo_pic_box.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.logo_pic_box.TabIndex = 2;
            this.logo_pic_box.TabStop = false;
            this.logo_pic_box.MouseDown += new System.Windows.Forms.MouseEventHandler(this.logo_pic_box_MouseDown);
            this.logo_pic_box.MouseMove += new System.Windows.Forms.MouseEventHandler(this.logo_pic_box_MouseMove);
            this.logo_pic_box.MouseUp += new System.Windows.Forms.MouseEventHandler(this.logo_pic_box_MouseUp);
            // 
            // anasayfa_panel
            // 
            this.anasayfa_panel.Location = new System.Drawing.Point(21, 98);
            this.anasayfa_panel.Name = "anasayfa_panel";
            this.anasayfa_panel.Size = new System.Drawing.Size(128, 99);
            this.anasayfa_panel.TabIndex = 2;
            this.anasayfa_panel.MouseClick += new System.Windows.Forms.MouseEventHandler(this.anasayfa_panel_MouseClick);
            this.anasayfa_panel.MouseLeave += new System.EventHandler(this.anasayfa_panel_MouseLeave);
            this.anasayfa_panel.MouseMove += new System.Windows.Forms.MouseEventHandler(this.anasayfa_panel_MouseMove);
            // 
            // çalışanlar_panel
            // 
            this.çalışanlar_panel.Location = new System.Drawing.Point(22, 216);
            this.çalışanlar_panel.Name = "çalışanlar_panel";
            this.çalışanlar_panel.Size = new System.Drawing.Size(128, 99);
            this.çalışanlar_panel.TabIndex = 3;
            this.çalışanlar_panel.Click += new System.EventHandler(this.çalışanlar_panel_Click);
            this.çalışanlar_panel.MouseDown += new System.Windows.Forms.MouseEventHandler(this.çalışanlar_panel_MouseDown);
            this.çalışanlar_panel.MouseLeave += new System.EventHandler(this.çalışanlar_panel_MouseLeave);
            // 
            // geri_bildirim_panel
            // 
            this.geri_bildirim_panel.Location = new System.Drawing.Point(22, 447);
            this.geri_bildirim_panel.Name = "geri_bildirim_panel";
            this.geri_bildirim_panel.Size = new System.Drawing.Size(128, 99);
            this.geri_bildirim_panel.TabIndex = 5;
            this.geri_bildirim_panel.MouseClick += new System.Windows.Forms.MouseEventHandler(this.geri_bildirim_panel_MouseClick);
            this.geri_bildirim_panel.MouseLeave += new System.EventHandler(this.geri_bildirim_panel_MouseLeave);
            this.geri_bildirim_panel.MouseMove += new System.Windows.Forms.MouseEventHandler(this.geri_bildirim_panel_MouseMove);
            // 
            // stok_panel
            // 
            this.stok_panel.Location = new System.Drawing.Point(21, 330);
            this.stok_panel.Name = "stok_panel";
            this.stok_panel.Size = new System.Drawing.Size(128, 99);
            this.stok_panel.TabIndex = 4;
            this.stok_panel.MouseClick += new System.Windows.Forms.MouseEventHandler(this.stok_panel_MouseClick);
            this.stok_panel.MouseLeave += new System.EventHandler(this.stok_panel_MouseLeave);
            this.stok_panel.MouseMove += new System.Windows.Forms.MouseEventHandler(this.stok_panel_MouseMove);
            // 
            // alt_panel
            // 
            this.alt_panel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(43)))), ((int)(((byte)(46)))));
            this.alt_panel.Controls.Add(this.btn_yenile);
            this.alt_panel.Controls.Add(this.düzenle_btn);
            this.alt_panel.Location = new System.Drawing.Point(172, 437);
            this.alt_panel.Name = "alt_panel";
            this.alt_panel.Size = new System.Drawing.Size(810, 121);
            this.alt_panel.TabIndex = 1;
            this.alt_panel.MouseDown += new System.Windows.Forms.MouseEventHandler(this.alt_panel_MouseDown);
            this.alt_panel.MouseMove += new System.Windows.Forms.MouseEventHandler(this.alt_panel_MouseMove);
            this.alt_panel.MouseUp += new System.Windows.Forms.MouseEventHandler(this.alt_panel_MouseUp);
            // 
            // btn_yenile
            // 
            this.btn_yenile.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(43)))), ((int)(((byte)(46)))));
            this.btn_yenile.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btn_yenile.ForeColor = System.Drawing.Color.SlateGray;
            this.btn_yenile.Location = new System.Drawing.Point(345, 84);
            this.btn_yenile.Name = "btn_yenile";
            this.btn_yenile.Size = new System.Drawing.Size(93, 27);
            this.btn_yenile.TabIndex = 1;
            this.btn_yenile.Text = "Yenile";
            this.btn_yenile.UseVisualStyleBackColor = false;
            this.btn_yenile.Click += new System.EventHandler(this.btn_yenile_Click);
            // 
            // düzenle_btn
            // 
            this.düzenle_btn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(43)))), ((int)(((byte)(46)))));
            this.düzenle_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.düzenle_btn.ForeColor = System.Drawing.Color.SlateGray;
            this.düzenle_btn.Location = new System.Drawing.Point(346, 48);
            this.düzenle_btn.Name = "düzenle_btn";
            this.düzenle_btn.Size = new System.Drawing.Size(93, 27);
            this.düzenle_btn.TabIndex = 0;
            this.düzenle_btn.Text = "Düzenle";
            this.düzenle_btn.UseVisualStyleBackColor = false;
            this.düzenle_btn.Click += new System.EventHandler(this.düzenle_btn_Click);
            // 
            // db_görüntüleyici
            // 
            this.db_görüntüleyici.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.db_görüntüleyici.Location = new System.Drawing.Point(188, 56);
            this.db_görüntüleyici.Name = "db_görüntüleyici";
            this.db_görüntüleyici.Size = new System.Drawing.Size(794, 369);
            this.db_görüntüleyici.TabIndex = 11;
            // 
            // çalışan_maaş
            // 
            this.çalışan_maaş.BackColor = System.Drawing.Color.DimGray;
            chartArea16.Name = "ChartArea1";
            this.çalışan_maaş.ChartAreas.Add(chartArea16);
            this.çalışan_maaş.DataSource = this.çalışanlarBindingSource;
            legend16.Name = "Legend1";
            this.çalışan_maaş.Legends.Add(legend16);
            this.çalışan_maaş.Location = new System.Drawing.Point(188, 311);
            this.çalışan_maaş.Name = "çalışan_maaş";
            series16.ChartArea = "ChartArea1";
            series16.Legend = "Legend1";
            series16.Name = "Series1";
            series16.Points.Add(dataPoint36);
            series16.Points.Add(dataPoint37);
            series16.Points.Add(dataPoint38);
            series16.Points.Add(dataPoint39);
            series16.Points.Add(dataPoint40);
            series16.Points.Add(dataPoint41);
            series16.Points.Add(dataPoint42);
            series16.XValueMember = "çalışan_ad";
            series16.YValueMembers = "çalışan_maaş";
            this.çalışan_maaş.Series.Add(series16);
            this.çalışan_maaş.Size = new System.Drawing.Size(768, 156);
            this.çalışan_maaş.TabIndex = 10;
            this.çalışan_maaş.Text = "chart2";
            // 
            // çalışanlarBindingSource
            // 
            this.çalışanlarBindingSource.DataMember = "çalışanlar";
            this.çalışanlarBindingSource.DataSource = this.eRPDataSet2;
            // 
            // eRPDataSet2
            // 
            this.eRPDataSet2.DataSetName = "ERPDataSet2";
            this.eRPDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // en_çok_satılan
            // 
            this.en_çok_satılan.BackColor = System.Drawing.Color.DimGray;
            chartArea17.Name = "ChartArea1";
            this.en_çok_satılan.ChartAreas.Add(chartArea17);
            this.en_çok_satılan.DataSource = this.satışBindingSource1;
            legend17.Name = "Legend1";
            this.en_çok_satılan.Legends.Add(legend17);
            this.en_çok_satılan.Location = new System.Drawing.Point(617, 56);
            this.en_çok_satılan.Name = "en_çok_satılan";
            series17.ChartArea = "ChartArea1";
            series17.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Pie;
            series17.Legend = "Legend1";
            series17.Name = "Series1";
            series17.XValueMember = "ürün_id";
            series17.YValueMembers = "satış_adet";
            this.en_çok_satılan.Series.Add(series17);
            this.en_çok_satılan.Size = new System.Drawing.Size(318, 240);
            this.en_çok_satılan.TabIndex = 9;
            this.en_çok_satılan.Text = "chart1";
            // 
            // satışBindingSource1
            // 
            this.satışBindingSource1.DataMember = "satış";
            this.satışBindingSource1.DataSource = this.eRPDataSet1;
            // 
            // eRPDataSet1
            // 
            this.eRPDataSet1.DataSetName = "ERPDataSet1";
            this.eRPDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // satış
            // 
            this.satış.BackColor = System.Drawing.Color.DimGray;
            this.satış.BorderlineColor = System.Drawing.Color.LightGray;
            chartArea18.Name = "ChartArea1";
            this.satış.ChartAreas.Add(chartArea18);
            this.satış.DataSource = this.satışBindingSource;
            legendCellColumn6.Name = "satış_adet";
            legend18.CellColumns.Add(legendCellColumn6);
            legend18.Name = "Legend1";
            this.satış.Legends.Add(legend18);
            this.satış.Location = new System.Drawing.Point(206, 56);
            this.satış.Name = "satış";
            this.satış.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.Fire;
            series18.ChartArea = "ChartArea1";
            series18.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Area;
            series18.Color = System.Drawing.Color.Red;
            series18.Legend = "Legend1";
            series18.Name = "Satış";
            series18.XValueMember = "tarih";
            series18.XValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.Date;
            series18.YValueMembers = "satış_adet";
            this.satış.Series.Add(series18);
            this.satış.Size = new System.Drawing.Size(405, 240);
            this.satış.TabIndex = 8;
            this.satış.Text = "chart1";
            // 
            // satışBindingSource
            // 
            this.satışBindingSource.DataMember = "satış";
            this.satışBindingSource.DataSource = this.eRPDataSet;
            // 
            // eRPDataSet
            // 
            this.eRPDataSet.DataSetName = "ERPDataSet";
            this.eRPDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // satışTableAdapter
            // 
            this.satışTableAdapter.ClearBeforeFill = true;
            // 
            // satışTableAdapter1
            // 
            this.satışTableAdapter1.ClearBeforeFill = true;
            // 
            // eRPDataSet1BindingSource
            // 
            this.eRPDataSet1BindingSource.DataSource = this.eRPDataSet1;
            this.eRPDataSet1BindingSource.Position = 0;
            // 
            // çalışanlarTableAdapter
            // 
            this.çalışanlarTableAdapter.ClearBeforeFill = true;
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // Yönetici_I
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(45)))), ((int)(((byte)(48)))));
            this.ClientSize = new System.Drawing.Size(1017, 560);
            this.Controls.Add(this.db_görüntüleyici);
            this.Controls.Add(this.çalışan_maaş);
            this.Controls.Add(this.en_çok_satılan);
            this.Controls.Add(this.satış);
            this.Controls.Add(this.sol_panel);
            this.Controls.Add(this.alt_panel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Yönetici_I";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Yönetici_I_Load_1);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Yönetici_I_MouseDown);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Yönetici_I_MouseMove);
            this.MouseUp += new System.Windows.Forms.MouseEventHandler(this.Yönetici_I_MouseUp);
            this.sol_panel.ResumeLayout(false);
            this.sol_panel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.geri_bildirim_pic_box)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.stok_pic_box)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.çalışanlar_pic_box)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.anasayfa_pic_box)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.logo_pic_box)).EndInit();
            this.alt_panel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.db_görüntüleyici)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.çalışan_maaş)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.çalışanlarBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.eRPDataSet2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.en_çok_satılan)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.satışBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.eRPDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.satış)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.satışBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.eRPDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.eRPDataSet1BindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel sol_panel;
        private System.Windows.Forms.Panel alt_panel;
        private System.Windows.Forms.PictureBox logo_pic_box;
        private System.Windows.Forms.PictureBox anasayfa_pic_box;
        private System.Windows.Forms.Label anasayfa_lbl;
        private System.Windows.Forms.Label çalışanlar_lbl;
        private System.Windows.Forms.PictureBox çalışanlar_pic_box;
        private System.Windows.Forms.Label stok_lbl;
        private System.Windows.Forms.PictureBox stok_pic_box;
        private System.Windows.Forms.Label geri_bildirim_lbl;
        private System.Windows.Forms.PictureBox geri_bildirim_pic_box;
        private System.Windows.Forms.Panel anasayfa_panel;
        private System.Windows.Forms.Panel çalışanlar_panel;
        private System.Windows.Forms.Panel stok_panel;
        private System.Windows.Forms.Panel geri_bildirim_panel;
        private System.Windows.Forms.DataVisualization.Charting.Chart çalışan_maaş;
        private System.Windows.Forms.DataVisualization.Charting.Chart en_çok_satılan;
        private System.Windows.Forms.DataVisualization.Charting.Chart satış;
        private System.Windows.Forms.DataGridView db_görüntüleyici;
        private System.Windows.Forms.Button düzenle_btn;
        private System.Windows.Forms.Button btn_yenile;
        private ERPDataSet eRPDataSet;
        private System.Windows.Forms.BindingSource satışBindingSource;
        private ERPDataSetTableAdapters.satışTableAdapter satışTableAdapter;
        private ERPDataSet1 eRPDataSet1;
        private System.Windows.Forms.BindingSource satışBindingSource1;
        private ERPDataSet1TableAdapters.satışTableAdapter satışTableAdapter1;
        private System.Windows.Forms.BindingSource eRPDataSet1BindingSource;
        private ERPDataSet2 eRPDataSet2;
        private System.Windows.Forms.BindingSource çalışanlarBindingSource;
        private ERPDataSet2TableAdapters.çalışanlarTableAdapter çalışanlarTableAdapter;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Timer timer1;
    }
}

