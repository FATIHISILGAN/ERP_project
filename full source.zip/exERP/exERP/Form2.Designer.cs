﻿namespace exERP
{
    partial class çalışanlar_düzenle_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.id_txt = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.çalışan_ad = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.çalışan_soyad = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.Maaş = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.Meslek = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.işe_alınma_Tarihi = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.son_görevlendirme_tarihi = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.son_görev = new System.Windows.Forms.TextBox();
            this.ekle_btn = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.sil_id = new System.Windows.Forms.TextBox();
            this.sil_btn = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.güncelle_btn = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // id_txt
            // 
            this.id_txt.Location = new System.Drawing.Point(140, 51);
            this.id_txt.Name = "id_txt";
            this.id_txt.Size = new System.Drawing.Size(100, 20);
            this.id_txt.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.ForeColor = System.Drawing.Color.SlateGray;
            this.label1.Location = new System.Drawing.Point(44, 51);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(28, 20);
            this.label1.TabIndex = 1;
            this.label1.Text = "İD";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.ForeColor = System.Drawing.Color.SlateGray;
            this.label2.Location = new System.Drawing.Point(6, 97);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(93, 20);
            this.label2.TabIndex = 3;
            this.label2.Text = "Çalışan ad";
            // 
            // çalışan_ad
            // 
            this.çalışan_ad.Location = new System.Drawing.Point(141, 97);
            this.çalışan_ad.Name = "çalışan_ad";
            this.çalışan_ad.Size = new System.Drawing.Size(100, 20);
            this.çalışan_ad.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.ForeColor = System.Drawing.Color.SlateGray;
            this.label3.Location = new System.Drawing.Point(6, 140);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(120, 20);
            this.label3.TabIndex = 5;
            this.label3.Text = "Çalışan soyad";
            // 
            // çalışan_soyad
            // 
            this.çalışan_soyad.Location = new System.Drawing.Point(141, 140);
            this.çalışan_soyad.Name = "çalışan_soyad";
            this.çalışan_soyad.Size = new System.Drawing.Size(100, 20);
            this.çalışan_soyad.TabIndex = 4;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label4.ForeColor = System.Drawing.Color.SlateGray;
            this.label4.Location = new System.Drawing.Point(8, 183);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(52, 20);
            this.label4.TabIndex = 7;
            this.label4.Text = "Maaş";
            // 
            // Maaş
            // 
            this.Maaş.Location = new System.Drawing.Point(141, 183);
            this.Maaş.Name = "Maaş";
            this.Maaş.Size = new System.Drawing.Size(100, 20);
            this.Maaş.TabIndex = 6;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label5.ForeColor = System.Drawing.Color.SlateGray;
            this.label5.Location = new System.Drawing.Point(7, 228);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(65, 20);
            this.label5.TabIndex = 9;
            this.label5.Text = "Meslek";
            // 
            // Meslek
            // 
            this.Meslek.Location = new System.Drawing.Point(140, 228);
            this.Meslek.Name = "Meslek";
            this.Meslek.Size = new System.Drawing.Size(100, 20);
            this.Meslek.TabIndex = 8;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label6.ForeColor = System.Drawing.Color.SlateGray;
            this.label6.Location = new System.Drawing.Point(7, 272);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(106, 20);
            this.label6.TabIndex = 11;
            this.label6.Text = "alınma tarihi";
            // 
            // işe_alınma_Tarihi
            // 
            this.işe_alınma_Tarihi.Location = new System.Drawing.Point(140, 272);
            this.işe_alınma_Tarihi.Name = "işe_alınma_Tarihi";
            this.işe_alınma_Tarihi.Size = new System.Drawing.Size(100, 20);
            this.işe_alınma_Tarihi.TabIndex = 10;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label7.ForeColor = System.Drawing.Color.SlateGray;
            this.label7.Location = new System.Drawing.Point(6, 358);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(128, 20);
            this.label7.TabIndex = 13;
            this.label7.Text = "son görev tarih";
            // 
            // son_görevlendirme_tarihi
            // 
            this.son_görevlendirme_tarihi.Location = new System.Drawing.Point(140, 358);
            this.son_görevlendirme_tarihi.Name = "son_görevlendirme_tarihi";
            this.son_görevlendirme_tarihi.Size = new System.Drawing.Size(100, 20);
            this.son_görevlendirme_tarihi.TabIndex = 12;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label8.ForeColor = System.Drawing.Color.SlateGray;
            this.label8.Location = new System.Drawing.Point(8, 313);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(87, 20);
            this.label8.TabIndex = 15;
            this.label8.Text = "son görev";
            // 
            // son_görev
            // 
            this.son_görev.Location = new System.Drawing.Point(141, 313);
            this.son_görev.Name = "son_görev";
            this.son_görev.Size = new System.Drawing.Size(100, 20);
            this.son_görev.TabIndex = 14;
            // 
            // ekle_btn
            // 
            this.ekle_btn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(43)))), ((int)(((byte)(46)))));
            this.ekle_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.ekle_btn.ForeColor = System.Drawing.Color.SlateGray;
            this.ekle_btn.Location = new System.Drawing.Point(87, 416);
            this.ekle_btn.Name = "ekle_btn";
            this.ekle_btn.Size = new System.Drawing.Size(93, 27);
            this.ekle_btn.TabIndex = 16;
            this.ekle_btn.Text = "Ekle";
            this.ekle_btn.UseVisualStyleBackColor = false;
            this.ekle_btn.Click += new System.EventHandler(this.ekle_btn_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label9.ForeColor = System.Drawing.Color.SlateGray;
            this.label9.Location = new System.Drawing.Point(50, 30);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(28, 20);
            this.label9.TabIndex = 18;
            this.label9.Text = "İD";
            // 
            // sil_id
            // 
            this.sil_id.Location = new System.Drawing.Point(436, 52);
            this.sil_id.Name = "sil_id";
            this.sil_id.Size = new System.Drawing.Size(155, 20);
            this.sil_id.TabIndex = 17;
            // 
            // sil_btn
            // 
            this.sil_btn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(43)))), ((int)(((byte)(46)))));
            this.sil_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.sil_btn.ForeColor = System.Drawing.Color.SlateGray;
            this.sil_btn.Location = new System.Drawing.Point(459, 95);
            this.sil_btn.Name = "sil_btn";
            this.sil_btn.Size = new System.Drawing.Size(93, 27);
            this.sil_btn.TabIndex = 19;
            this.sil_btn.Text = "Sil";
            this.sil_btn.UseVisualStyleBackColor = false;
            this.sil_btn.Click += new System.EventHandler(this.sil_btn_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.groupBox1.ForeColor = System.Drawing.Color.SlateGray;
            this.groupBox1.Location = new System.Drawing.Point(352, 22);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(287, 118);
            this.groupBox1.TabIndex = 20;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Sil";
            // 
            // güncelle_btn
            // 
            this.güncelle_btn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(43)))), ((int)(((byte)(46)))));
            this.güncelle_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.güncelle_btn.ForeColor = System.Drawing.Color.SlateGray;
            this.güncelle_btn.Location = new System.Drawing.Point(87, 443);
            this.güncelle_btn.Name = "güncelle_btn";
            this.güncelle_btn.Size = new System.Drawing.Size(93, 27);
            this.güncelle_btn.TabIndex = 21;
            this.güncelle_btn.Text = "Güncelle";
            this.güncelle_btn.UseVisualStyleBackColor = false;
            this.güncelle_btn.Click += new System.EventHandler(this.güncelle_btn_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.label10.Location = new System.Drawing.Point(3, 3);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(14, 13);
            this.label10.TabIndex = 28;
            this.label10.Text = "X";
            this.label10.Click += new System.EventHandler(this.label10_Click);
            this.label10.MouseLeave += new System.EventHandler(this.label10_MouseLeave);
            this.label10.MouseMove += new System.Windows.Forms.MouseEventHandler(this.label10_MouseMove);
            // 
            // çalışanlar_düzenle_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(45)))), ((int)(((byte)(48)))));
            this.ClientSize = new System.Drawing.Size(703, 482);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.güncelle_btn);
            this.Controls.Add(this.sil_btn);
            this.Controls.Add(this.sil_id);
            this.Controls.Add(this.ekle_btn);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.son_görev);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.son_görevlendirme_tarihi);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.işe_alınma_Tarihi);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.Meslek);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.Maaş);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.çalışan_soyad);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.çalışan_ad);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.id_txt);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "çalışanlar_düzenle_Form";
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.çalışanlar_düzenle_Form_Load);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.çalışanlar_düzenle_Form_MouseDown);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.çalışanlar_düzenle_Form_MouseMove);
            this.MouseUp += new System.Windows.Forms.MouseEventHandler(this.çalışanlar_düzenle_Form_MouseUp);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox id_txt;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox çalışan_ad;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox çalışan_soyad;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox Maaş;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox Meslek;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox işe_alınma_Tarihi;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox son_görevlendirme_tarihi;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox son_görev;
        private System.Windows.Forms.Button ekle_btn;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox sil_id;
        private System.Windows.Forms.Button sil_btn;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button güncelle_btn;
        private System.Windows.Forms.Label label10;
    }
}